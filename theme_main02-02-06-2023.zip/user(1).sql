-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 30, 2023 at 02:01 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `responsiveform5`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `name`, `email`, `password`, `cpassword`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(65, 'vaneet ', 'vaneet@ocode.co', '$2y$10$yn3JqpLAo092EQmjb.oc9u9dr7or2uVAJHh3HGuBH2kcJn2VtXpg2', '$2y$10$7MKsaEtX.qwPMEzTFPok/OT403.Ab/.g7j09VNZvlIKk/5aovEISm', '1234567890', 'una', '2023-05-29 11:24:05', '2023-05-29 16:54:05'),
(66, 'vaneet', 'vaneet123@gmail', '$2y$10$dSevvzc/1vMYkclqMHZCduHyzOofnYIw2Ys4jtxmOFv.qiBj4F3iS', '$2y$10$inru./WwH1hkbUDinqVKbOhLQGpHQov1WUUb3BjPrupud9/7Iz6be', '1234567890', '1234', '2023-05-29 11:52:35', '2023-05-29 17:22:35'),
(67, 'vaneet', 'vaneet123@sv', '$2y$10$9MbnIwRbSGeaf4CYkoXYYeuNLMPvviByPbOVQVDZmtp8WjtNimQ/K', '$2y$10$TO6Egs1nScbY5dejpaTcWemFK.unOPs0VivsjEo6Da8hg03fkJlAa', '1234567890', '1234', '2023-05-29 11:53:00', '2023-05-29 17:23:00'),
(68, 'zdhnb', 'dfhgnb@erdghb', '$2y$10$bgayB/tctUgbzBB9EvfG3eTMCYUIGHyQCKw7VwV9Jxn/NXwKRN39y', '$2y$10$OlD4r2s/n4ILhmCbb6YW4ebogl4lhrHyq.6MdK3kBsHAunxIerRo2', '1234567890', 'dzfbg', '2023-05-29 12:10:50', '2023-05-29 17:40:50'),
(69, 'dfb', 'dzfnbhg@ffdfr', '$2y$10$JWAlI8Ac1UiAzTV/lBTSK.WRBArgU0dEtc6JWywX.qzZTYPrJU2F6', '$2y$10$3qz9wrd.XZ8rKPwx47xQ/uE1jyRPY.T4EzuLjIVUYoEJ454iE23cy', '6283951020', 'fvghj,k', '2023-05-29 12:26:11', '2023-05-29 17:56:11'),
(70, 'bunty', 'vaneet12@ocode.co', '$2y$10$3Nwdu5Tkj6LJiJNvlBYdr.uCdSvXY9AiwNYgJ4mRGgYY4kyE9FOXa', '$2y$10$HUzo8eihiLOzrfvKa37L1OQblEXWn4Tmm20y79jSwCYONf2SSf/z2', '1234567890', 'una', '2023-05-29 12:27:58', '2023-05-29 17:57:58'),
(71, 'vaneet@kk', 'vaneet@kk', '$2y$10$tsRqoqgKW1wXMR0n8d8l6.CluLujOoBE8aX1wtzQ16TmWfpvMrXvW', '$2y$10$rJlQSRrRSqel7hEw9ucIpuXfaW.wLU6Wk9oGiqhCTU2TGd2n4KDU2', '1234567890', 'una', '2023-05-29 12:31:10', '2023-05-29 18:01:10'),
(72, 'vaneet@kk', '', '$2y$10$cI9pv6A9fzRMAr88D81Z2ejW2gAtqzZydMRWtNRCVjII0RCQSFs9G', '$2y$10$IeB1QX0NIqcBlAWk/.jeUO28jIHfEYEJ.B.JnspF.xP.VtY8Feahq', '1234567890', 'una', '2023-05-29 12:32:23', '2023-05-29 18:02:23'),
(73, 'Bunty', 'vaneet@kk1', '$2y$10$nhai4qjGbd58eiVN3sCZNuOLkTb8VjATFc3FJHAkM8bnh0IYwQ9qm', '$2y$10$AWbZvA.rMS2gZ4KrcpmlfudcLiudRXwMZqfH/iEJqUN81lAoTCKyC', '1234567890', 'una', '2023-05-29 12:42:32', '2023-05-29 18:12:32'),
(74, 'Bunty', 'vaneet@kk12', '$2y$10$mS6aAhZjZdTGFcRD8pT2peAWeR7A64CsBJdJgS4AuW3IH2/TEU2qG', '$2y$10$8.kzYTKRc4FvvjXRskHgneiTRIAc1/umihAM4gkhMgWogmjRo4rQC', '1234567890', 'una', '2023-05-29 12:44:26', '2023-05-29 18:14:26'),
(75, 'Bunty', 'vaneet@kk123', '$2y$10$cohsgXwz/HWTxcr4bs9sSeYfm7s19OxtTvvhvoauGwFOXHW.Xevry', '$2y$10$0KtBiBwp8zHZxCKpKzJ2h.tj7IZ9GtjHaAecawte6QOS4raOhd2qi', '1234567890', 'una', '2023-05-29 12:47:34', '2023-05-29 18:17:34'),
(76, 'Bunty', 'vaneet@kk1234', '$2y$10$jVf142sdH.4OEqJ3nGEEXOcyXjFYUTawQV1UU69753FBwS3dDSYmO', '$2y$10$YpOq6Rw4tpULOsxiJS7jh.Ln9IAhbqued4UZe4Rw9.W96fMgmNRiK', '1234567890', 'una', '2023-05-29 12:49:54', '2023-05-29 18:19:54'),
(78, 'Bunty', 'sss@gghh', '$2y$10$SpMCXpbgpzIQedEeCuqqiuHNpd1L.viyn6XDS6Zw6WpMbwI.m.kwy', '$2y$10$mnUOxjuevs0TW4E17G4VG.y.z0i4SLEQZ5CW6CvnRlztyQNSJ/LOi', '1234567890', 'bsa', '2023-05-29 13:20:45', '2023-05-29 18:50:45'),
(80, 'ramesh', 'ramesh@123', '$2y$10$f/SwnrdTNfN2XLeckkr4zeD5CygALk6lty00dqW4i12BYqRzZOwzS', '$2y$10$iQr95H0kkc1KRuN4ZN1RiOKp8QIerBWVmpH//Rbym4IHmWYlA6gVe', '1234567890', 'una deoli near mandir', '2023-05-30 05:23:15', '2023-05-30 10:53:15'),
(86, 'khanna', 'khanna@gmail.com', '$2y$10$U6iDVx.q7U.fvoTiPAjpWuDWWOsmfjP9N3lT043wbSAlmpCsSoqMm', '$2y$10$0blO4ieDLpLYpMo2HS3k/.Sc8/pVT8MYnkP57u4tZcjTgTYWrcuQq', '1234567890', 'una deoli near mandir', '2023-05-30 07:59:06', '2023-05-30 13:29:06'),
(87, 'Bunty', 'bunty12@gmail.com', '$2y$10$m3xwiqzQWSTevBBBy1wi5erjOSybsN1ppaYoaXPqJ3n2sVmP5s2ya', '$2y$10$u.goI95j7r4AFCHn2XSOhOi8uzoLERA1nXlajwTGIyOgVG2XPufT2', '6283951020', 'Una deoli gagret', '2023-05-30 09:18:49', '2023-05-30 14:48:49'),
(88, 'vaneet', 'vaneetkuma798@gmail.com', '$2y$10$Uk2eDTeWM3.zz5VcmnUQv.7IhjiOj7N8nTLoEWSiGqobj1vlPfoLW', '$2y$10$ARkw5BsBqud1BNGfPDS8F.AzJ6qvrlir1PcH1QFdSiOkmHcVxH/oO', '1234567890', 'dfhhhhhhhhhhhhhhhhhhhhhhhhhh', '2023-05-30 09:30:00', '2023-05-30 15:00:00'),
(89, 'name', 'newuser@gmail.com', '$2y$10$ntwsExr8FyRpLTsb5KfN/.Y/q8d0voA9e4wyGKHwnmc.YR0qD2HBe', '$2y$10$XOgw.tWQqW7Y8pCheGIgNefU16DyxbEmP.ntCOMHtkvUt3epBizji', '6283951020', 'Una deoli gagret', '2023-05-30 10:25:07', '2023-05-30 15:55:07'),
(90, 'rohit', 'rohit@gmail.com', '$2y$10$B9uuh4IoOA5iNBRXVWKlp.u093Fn4hBy8ba87P4xtBwADMMFxflCW', '$2y$10$.Mr9MzINrt/GpSYlcWkZZelHN1x.faylsEGFu1xdbPibEdEi4kDCy', '1242354356', 'sdfgnjdfgnghnjgh', '2023-05-30 10:39:20', '2023-05-30 16:09:20'),
(91, 'Virat', 'virat@gmail.com', '$2y$10$zMwWUi5SRizeZ7vwt.Hcr.tv0rv2LWHiH7Vjicl98nUJ9uVxgYwO.', '$2y$10$mmXAD.NzPr7wLMW/JuBQzeeQeGhirXdI5AWnDqp4StccMEtgmfup.', '1241235435', 'una deoli near mandir', '2023-05-30 10:53:04', '2023-05-30 16:23:04'),
(92, 'shikhar@gmail.com', 'shikhar@gmail.com', '$2y$10$oHBlX8iSqoDVDZ3E3iDu3OUyBsXrenfmhsnhpFY80lGbptNZW8vHe', '$2y$10$qrAUVB4kxiJxS0cTXqd58OnXiTy5HQRYszPus0nHIfSjkGjsDo4qa', '1645765467', 'una deoli near mandir', '2023-05-30 10:56:27', '2023-05-30 16:26:27'),
(93, 'MANISH', 'manish@gmail.com', '$2y$10$W5ZjGj4H9eA6ucuIq41Oj.6WpnvcjZ4LI5jwpU72XbpZ8xS1A0y1K', '$2y$10$b0m6UXDbqRZMLgkO37HWue80E7/Ikxp50uY9A2uXzXSZn7rMNi6ae', '7568756846', 'una deoli near mandir', '2023-05-30 10:57:50', '2023-05-30 16:27:50'),
(94, 'sfrgjm', 'fgjn@gmail.com', '$2y$10$0Ue4Vm0w.wf9H2hQgh3jJ.l5HjIBRTY0fBm.A/Wr2KCo5zIPRrYd.', '$2y$10$q96AUmpIncJAoyaiPIV/NO3CZXGPp8QoFcHzVZL85rMEwSJL0syUG', '4357567868', 'fghkmhj,kflhjk,mhjbk,l', '2023-05-30 10:58:55', '2023-05-30 16:28:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
