<?php
session_start();


session_unset();

header('location:https://www.psd2htmlx.com/w/dashboard/pages/sign-in.php');

?>