$(document).ready(function() {
    $('.delete').click(function(e) {
      e.preventDefault();
  
      var objectId = $(this).data('id');
  
      if (confirm('Are you sure you want to delete this object?')) {
        var button = $(this); // Store the reference to the clicked button
  
        $.ajax({
          url: 'delete1.php?ID=' + objectId, // Modify the URL to pass the ID as a query parameter
          type: 'GET', // Use GET method to pass the ID in the URL
          success: function(response) {
            // Handle the response from the server
            console.log(response);
            // You can update the UI or perform any necessary actions here
  
            // Assuming you want to remove the row from the table on successful deletion
            button.closest('tr').remove();
          },
          error: function(xhr, status, error) {
            // Handle error
            console.log(xhr.responseText);
          }
        });
      }
    });
  });