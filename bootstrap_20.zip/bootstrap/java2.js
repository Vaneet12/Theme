window.onload = function() {
    let godesti = localStorage.getItem('destination')
    document.getElementById('desti').innerText = godesti;
    
}

function pageRedirect(event) {
    localStorage.setItem('day', event['target'].innerHTML);
    window.location.href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/Date.php";
  } 
