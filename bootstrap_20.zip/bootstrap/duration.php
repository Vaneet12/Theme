
<?php
session_start();
$userprofile=$_SESSION['username'];
if($userprofile==true){

}
else{
    header('location:sign-in.php');

}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://kit.fontawesome.com/1b5688f48a.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
    <script src="java4duration.js"></script>
    <link rel="stylesheet" href="tour.css">


</head>
  <body>
  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 text-secondary">Home</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Features</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Pricing</a></li>
          <li><a href="#" class="nav-link px-2 text-white">FAQs</a></li>
          <li><a href="#" class="nav-link px-2 text-white">About</a></li>
        </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>

        <div class="text-end">
        <a href="logout.php" class="btn btn-outline-light me-2">Logout</a>
          <a href="profile.php" class="btn btn-warning">Profile</a>
        </div>
      </div>
    </div>
  </header>

<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/main.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/home.php"  class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                        
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Orders</span></a>
                    </li>
                    <li>
                        <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                            <i class="fs-4 bi-bootstrap"></i> <span class="ms-1 d-none d-sm-inline">Bootstrap</span></a>
                        <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 2</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#submenu3" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Products</span> </a>
                            <ul class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 2</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 3</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 4</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Customers</span> </a>
                    </li>
                    <li>
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/index1.php" class="nav-link px-0 align-middle">
                         <span class="ms-1 d-none d-sm-inline">Tour & Travel</span> </a>
                    </li>
                </ul>
                <hr>
                <div class="dropdown pb-4">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30" class="rounded-circle">
                        <span class="d-none d-sm-inline mx-1">loser</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                        <li><a class="dropdown-item" href="#">New project...</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/profile.php">Profile</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/logout.php">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col py-3">
        <div class="swit_submain3">
        <div class="text_div">
            <b>PLANNING YOUR TRIP TO</b>
        </div>
        <div class="switzerland">
            <div>
                <span id="desti"></span>
                <span id="test"></span>
                <span id="travelmode"></span>
            </div>

            <a target="_self" href="/">
                <i class="fa fa-times" aria-hidden="true"></i>
            </a>
        </div>
        <div class="progress_div">
            <span class="yellow"></span>
            <span class="yellow"></span>
            <span class="yellow"></span>
            <span class="grey"></span>
            <span class="grey"></span>
            <span class="grey"></span>
        </div>
        <section class="when_to">
            <h1>What's the duration of your holiday?</h1>
        </section>
        <div class="duration">
            <div class="stay_duration" onclick="setDuration('3-5 days')">
                <div>
                    <label>
                        <span style=" background: url('https://www.psd2htmlx.com/R/multistep/images/common.png') 1px 0px / 534px 220px no-repeat;"></span>
                        <p>3-5 days</p>
                    </label>

                </div>
            </div>
            <div class="stay_duration" onclick="setDuration('5-8 days')">
                <div>
                    <label>
                        <span style="background: url('https://www.psd2htmlx.com/R/multistep/images/common.png') -100px 0px / 534px 220px no-repeat;"></span>
                        <p>5-8 days</p>
                    </label>

                </div>
            </div>
            <div class="stay_duration" onclick="setDuration('8-10 days')">
                <div>
                    <label>
                        <span style="background: url('https://www.psd2htmlx.com/R/multistep/images/common.png') -209px 0px / 534px 220px no-repeat;"></span>
                        <p>8-10 days</p>
                    </label>

                </div>
            </div>
            <div class="stay_duration" onclick="setDuration('10-12 days')">
                <div>
                    <label>
                        <span style="background: url('https://www.psd2htmlx.com/R/multistep/images/common.png') -314px 0px / 534px 220px no-repeat;"></span>
                        <p>10-12 days</p>
                    </label>

                </div>
            </div>
        </div>

        <div class="main_reviwe">
            <section class="review">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgWFRYYGRgaHBoaGhoaGBoaHBwYGhgaGh4aGhwcIS4lHB4rHxwaJjgmKy8xNTU1HCQ7QDs0Py40NTEBDAwMEA8QHhISHjQrJCs0NDY0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAIDBAYBBwj/xABIEAACAQIEAgcEBwUFBgcBAAABAhEAAwQSITEFQQYTIlFhcYEykaGxFCNCUnLB0QczgpLwFTRiorIWJENTc8JUY4OT0uHxF//EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EACgRAAICAgIABgIDAQEAAAAAAAABAhEDIRIxBBMiMkFRQmFxgZGhM//aAAwDAQACEQMRAD8Ag6Qfux+NfkavcJ2FU+kI+rH4x8jV3g+woLsZmqwmwonboXheVFLdUELC1MKhWpaxh1R3dhT6bd2oMJmeJjtnyHyqsoq1xL2z6VXWkDY5RTwK4opwFY1na7SWnGswobFOAroFOArGbI35VSxy/XWP/U/0VeuDbzqpi9b1n/1P9FNHoVlkU8U0iKctEAwiupzqQrTAN6Jh4pRXFpxSsCzlQu7j2VBHnFT5TUNy3r7ZXwkVg2SASNRrXCg7qeg8ZinFKxrIurXuHuFKpMhpVjWYfpD+6H41+Rq3wc6D0+VVukS/VD8a/nVvg+w9PlSLsZmqwg2orbFDMJy8qJW2pxSyoqUVFbqWsYcBUd6pBUVygYzfEh2z6VAoq1xEds+lQRSjCUU/LXEpzUDHVqHHYxLKF7jBUG5PyHeaodIONphbed9zoi82aJ91eQcd47dxT57p0HsoJCr5DmfGs2Y3+P8A2jYdP3SO51mRkA9TqfQVSH7Szp/u3f8Ab932a84zCnTG1YB6Vh/2kIxGeyyjmVYP8IFaHCcYtYi7Ye04ZfrJGxU5BoynUV4vm7qs4PGvadbiMVZToR8iOY8KydGPfrqaEih1vFvpIT3t/wDGl0a4uMTYV9j7LDuYbxVm5hV8dP8AEadAGHFN3L7yNPdUiXwVJJA8jNO6gRufeaeloQdT76JhiXAdjVhGqFMOBzPqf60qUECsKONRm2p3UeoqwtNZedYxGigbCPKnzrXRXedAxyaVPgf0aVajGH6Rj6ofjX86m4P7IqHpKPqR+Nfzqfg85RSR7KM1eF5eVELZofhNhRJBVBSxbqeq61OKxh52qG5UpqK7QMAMf7Z9KrirGP8AbPpVdaAw9a6ZpKKfQMYD9qiHqrTAaZiCe7QED1191eX16j+1m0TZstyDkHu1U/pXlyLrQYCS3aLbCamXB3OSN6A1o+F21A0FbrgmER0PZGnhUfM3R0Rwem7PLcHwO/cICodefKjF/oTiVTNoTE5edel2sKymABFOxysoE0JTaHWGPRhv2c8W6prtpw52YAKWIKnK0gbbj3Vvzxm2eT6/+W/6Vl+C4dU4o7Ls9lmYD72ZNfh8a2+o0gxV4yuJyzjUqBw4xbU6h/8A23/SnDjFoE6v/I/6VfzNHs10THs01oSiiOMWfvN/I/6Um4pZ+/8A5W/SrhB+78q4rN9z4ijaDRTXjVgbuPc36VOnGLB/4i/GpTJ3tj4VzJ/g+VawURNxGz/zE99NHGLA/wCKn8wqxP8A5YP8tLKp3tfBa1moh/tix/zE/mFKpeqt/wDJ/wAq0q1moyvScfUj8a/nU/CB2RTOk4+p/jSn8I2FKuxzU4TYUTShmFGgonapxSxbFSrUduplrAZ0jSoL1WH2qveoMIBxo7Z9KYq1Li/bPpTBShEBXYpUqxjO9PMMHwN6QJQBx5qwP6++vG8Fblq13S7E3Rib7OxyqQiodVyRoI21GvrWfwCgOQRBJGndNTlLsqo1RZTi3VghEUnmzbegq3gOmOItnZCO4aUSw/Rxbu0TuP8A8pmL6IBNXIHgNPzqSlEu4T+GaG300AtBypI8ufdQHE9O7jvC2lI/xNrHpR/BcHW5gntARBBBA1g8waB4foMwbtLIP2gx+VKq+RpRlqjR9DryX7zX1QqVtm2Qe9mU6HmOyffW0isl0fw7Yd7dtBKuzBz4KrGfeAPWtfV8bTjo5ssWpbI4ro50m+e1OVd6oSGUqdkprA907VjCroWnKtPrBojyUop1KiahmWlUtKsajEdJz9T/ABrTuEnQU3pOPqf40+dc4UdB6UsezGtwg2opaoVhdqKWNqoKWlqYVAhqZTWAPaq96pmqG/QYWBMV7Z9KYKkxftn0qOlCdUUH6WcY+iYdrqgF9FQHbO2gJ8BqfSjK1kP2oYcvgSwnsXEY+Wqz/mFYx5nY4xcuXHN0h2uHtF+fgPu6aCquKOW5IPxn0mqVOU0jjuxlN1RsOCceZRvtU3EePbXFbO6kdg+zERr31j7bxWgtYG31auCdfaANScUnZ0xySkqQb4P06yI4a2obkAYU/pWgwfG2GVgVyOJyhpKMeUnWKwuHwWHdgFuHN3FAfiIp2Owz4dw2cElTAGkTptNLKKfQ3KUVctnpnAcUt687LsgCxyltfyrS1l/2fYEJhEc+3cJdj3iSF+A+NacVeEeMaOWcuTs7XJ0rtd76oKcptOpVgipVwV2gA5FdpV2sA5SpUqxjEdJz9T/GnzrnCdvdXek6/U/xp8zXOE7e6hHsJrMG+gopYNCsBEUUtVQUtqalWoFNT26wp1qY4qRxUb0GGgPi1Gc+lQ5anxY7dREUBjgod0ks58JiFABJtPE7TkJFESYoHxXj9gIyKzOWDIerGYLKkatsPfWGjFy0jxS1gGKZ40O3l94+E6TUKLpsK2WJhkW1bACgCTG5A0+BgLsIoDieHlNdwdJ5ZhuKSTovLC4/AJbuonwvinVgjcHlVG5bg1y3bnelbTJU09Gm4bxiyrFmtJOsGr3BOAXOIXjcPZsK0M/Mga5EHf47CfSs5hsGrcq9C/Z1xULffC6BSi3E/EoAYd2xB9KWNNjSUuOz0G1ZVVCqoCqAABsANAKkyiugUstWJHAtIiugUjWMMjwpBfCnUqJhBRXQoroFdigAblFcJA3gedeYdPenTpcfD4VsuXs3Lg1ObmqchHM15zcx1xzL3HY/4nY7+ZoWY+kevt/fT+YfrSr5s9fjXaFmPXelP7j+NPmai4RsKm6Vj/d/40+ZqHg5lRRj2E13D9qJ24oXgDpRJDVBSyoqxaqutWLVYUkaomqaq2MvKiM7GFVSxPgBJrDArGuFJLEAaakwKC3ekFqcqBnMxoAAT3Aneg2P4k9689t1AcjNZCtK6CSpOxO4nwNCL3DnDqQ5i5AIWOw/2Z7p28yKCi6s7YYYquWwxieNg3UFwfVXM9tkbK2RiBkIkfPuO1ZXi+Ki4CNgCPZ7MqTEACAI0jwo7iOHJbzG64V8hZc8McykNmyqez7J376s8XNgqQCzgOlxXS2WUJdVjl79XDeAkUauNMvLjGS4qkzH4TiKJazsO/seIPPnBBGnOfChI4u124FdotsYIA0WdmA7xptWgxHRzPcD5CEzQQ7ohOv3dxIJoPxfgnUqzaDK5RlRg0ACQxjUTBqVaEyc3TfQOvL76jVaKNgcyB0IYH7pmDuQfHWhN85Wj1qS3ohNcdsuW8Tlol0Huv8AT7bqTIzZtCeyUII9wJ9Kz9u4CYIorwlzYd307IkTOrAEqBHeYp4JRewRfN6Pc8Bjs8KysjgSVYGIJKyDsdR31frDf2opZbiEg9RcJUmCBIJG2u+/gKLWuOsjlDDqCO0WAYKQNO4nnr76s4/I0vDt+3/DR1yKhw2LR/ZOvcRB9x39KsGlOeUZRdNDAKdSpVhRAUnmDHcflTlqDiOK6u09yJyI7x35VJj4VjHz/wANwquxziSzEnv1JrSYfozhmHazidiNfSss+IvLcZ0BXMxaANBJJgeAmitzjOMREJACuMwMeY17q55J3pnVBx400Ff9kMN99/dSoJ/tLi/8H8o/WlQqX2NeP6PQeln93/jT86rcDPZHjU/S0/7v/Gn51R4C/ZH9c66F2chtsANB5UStihuAbQeVFLNUEZOgqvxDjNjDIXvXFQDWCZY+SjU0J6W9J7WCslnINxgertzqx7z3L414HjuIPdd7jklnYk695n3UJOjUevcS/axh10s2nc5oOYhFyie0NyZ7oFZvi37Qb2KtNaFkJLAkq5MouuU6bzHurzsmtD0dwoyu5iLa5yCQDHgCQTuNqS2WxQ5SoLYLFFikvkZGygtujSbg8hmkHzE86K8U4wL1gspKWwwi2B2ndYbM5+4Tt3waynFAVe6ZIObkNSCx394NWhjmKOz+06DMe65b1BHIZ0LUYyvR3P0vfwaxsUspkCIHR2OUT7Sc5k8u+osbfL2gS5kWQBrBBS4QPhPvoNhsLdYWyXCgoREaQEPPlRnh/Bi2FUurvmRYIB9nO8/kfdTQjd2UnPUaKeAxK5HzEaQYn05edWsdbtv9JBiHtW35/dWTv3k07D8AIJItdll1LFRqBz186K4PhBZ0UohzYd7Zhhydo+AFZRp0Gc3KFv7PNOH3nwzsja22ME8o+y49CD5GqPG0yXiBtlUjXcHWa2PFOjrZ0Uo6hgdVgjx2PLceorMdI8A1trYaZKZdQRORo5+dTcKlZxZF6ATbYBhE8q2LYH6RiTcVEyMQ3Vs3V5csZkk8wec86ydixqDzGu3drW64Ji8+Z3MsdWLCCSeWkcpNZB8LFSbTNVh8HaZCpGRxh7mVLhggEgSrbFZqHiHCicQXVGyBQGZO0rabiNT7qv4BhNwA9lLdtSGAZcztmbQ8xMbUFa+rXWIzoztDNbcqNAB7MRy8KtySjs6uEnNuIRCXEDkMHVBbdQQVaQVEa94ZhWhtcRAuG00zJCk77Bgp9Dv4VmsDj3OZGdbyMywrjI4Re02Uj2iOzpPKm47Fdc9u9ZcauWzEQUO2Rx5TQVOJPNjbdNbo2wNSVEpBAI2Oo8jWU6Y9ObeCItoouXTqVzQEHIue891Iec1TNioqh0gtF8NfUGCbbie7sGvKm6fY9yHDpbWNEVA0zzJbWuv+0LFhCj9W4IKtKZSwYEfZOm9K2jGcTioFqNCxjfurT8I40lxh1lu2ECBQucHUAADKRpWAsFeeoG01dxNyyUGVYfvBPympygi8crPQvpNn7ie6lXm/9ot3/GlSeW/sr5y+j1bpcs4Y/jT5mqXAR2aI9KGDYaQQRnTUetU+CJ2a6UtnGa7hw0FFkYbmhGA8K8+6Y9Pry3ns4Zk6tRkL5cxZo7UGYgHT0p26Aa3ppgeH37Iu4h4I7KXLZzN3wAJDDc614ri7KK7LbfOgPZcqVLDvKnaozinjJmITU5Z7MneBypmc0jdmot4bBZoJMCtTwi3bGDxTNbVyVQAkkOJuZZHdyMVkcM7TAJjWfKtlwvhspklhmW258lYk0I9uzpxRvoHcTswiXACykZXY6srKQIIO+mWCPGquKt5VUFTLMAo8jqp8m7+VSK75HsNLAnOpG4fnPmCRT8TiWxDWGcqSkI5gKYBWGJ+3I9aHxaOmT9W0bR8XkWfo9pMqPOd+sYdkjYHXWob/ABLNbVDevEGykBCtsCAdAATp40I49fVUKK0dhp5zuSflQ+5xMFEC5ierRYG0AN3U8ZPZXI4KlV6+wnhnQquZHcwdXdyRp4AUZwDoLtgiyuoux2n5an7XjWLwNxyiwk76k76edGsC13PhuwP+MNDP2RtSR5OQ/OPBql8BPiK2ptPNxNNGtuRBGoMMOR8ayvTHFXLrWmdi2jhXbQsAyyI2EeHea0CEu1hHDBSpIjTYQRPdNFuI4DDjq+tw7OqKQmjsAG1OYDcyOdbJOnRzzUZQpLZhOA2FN9A7hV1k+1HZMaDfWK9JXhKMERDbeSMxBhsu2qnnE0IwWKwK30yotth7JAyRIIIPgZ50QxRzs75Ucqr9pD2wcrAEldjGutCGRPQfDY2rSe+zr2gmHcjMj3bpaGkDIs6Dv100rPWLr28zOCxzGGXftLvptRjG8QdLSLbuA5LQBS8Myktv2h5jeKj4Ndt3GW1ctmyxKgFe1bYztI0BiatJpoeKlF7Ky4hVa4SQOqsGSND1lwb6cwGA/hqth8Uzpcuzld1y8u2NlJ5AjXWndMsP1VsDKue6+cshzKyEnKARvttQJ7jwETTPlnWQpn2QeZ199Tla0hoZIuTcv6PT+jnEXfAG4RDot2ANdVzMkehWvCjfa45ZyWZiWYnck6mfWvbuiiKn0iynaQBXVp0Ie2OyB4aAmvELKFdCIrNUeZkVSZZS4ddfGorz6a71HmiP676ddIOo/rmaUmVxVnD2AahW2Zq5hbTTG1CTKQVln6EtKrPUL9/4UqS2W4o2rNIysJBPoY51f4XbC6A6d3MVl7OIgMCT2WjU8oBBonhcWdDt848a9SUYyPJjOUQt0u439GwrFfbuTbt+BIksfJZ9YrxdRArf/tPeUwxkwc58Nk+O9YjA2wzqDtXFN0dcVZb4Vwe5dYQuneTHunerr8BclgEYZd9CQPWjo4zbw6DKgdz7IOw8T4VoOjXHHviHVWG0gZde4A6wO81Hk+zpWKN1ezz7AcOOcjKzbCFGpnureWsIUcs1m4iraYli6mCeyDlVQTqw56VR6U20s31yBgzZWbLP3vDnp8KvYLjH1jrDgsIGYloIKNrPLTarRScbZ04rjJRiZ/imFPauW2DFWElDOm5zDfQd4rvGMAnZcR2ygEaEgJmJEd3hRN0s4i6Fe1lYmWe2ch75y8zVTi+EZfo0XS9sNdVHAAcBcpCspjUSQD4Hwo8eKbHm1J9bLK8AORnKDW25zOYJhWOhOvwqnibdpEthryCbSmFBcjTYkbGraLaaMyvcJBBa47HUqw0AgAepqHD3ItWioRewwkAEkBiN4JHPnRjJfAZ42kraWitgL2HCA/XPy7CKJ05iNqN8Pu2w9g/R8SADe9lf8K6xQJb1zKFBdu4iZ8ommf2iQi5WKupuDf72UaGd9D76Tk07oL4KLV/XwTLxA9dbKllQFVGeJRTvtynX0Fbp1vBAbTI5/EQCO+TNeZMpI7vGtJwPiShDZuORr2HQwy+GsgieRFcs/U7IxfwEsfjsSARdwxywZZSjCI12MnSascHRLfWXMO5WV0z9tJbIoBEZo9/wqni1xAAyX0uKSIBXI3kDJE+6pMPc7dq2B1ZuXFOWBARBJEbRqf5aphvlorGuLsudKcjAI6ZCuVM6DMm2YkgeyJ7xND1w5w5663cW4NB2ToXJhVKnnJ+FT8Qvl702yQ5DMwDRmDGQAd9o01oPx7Fi2i3FAViTCkZSTEB8o00kjzM8qtKm+h4ycIXf9MDcc4oXxKqAMttjbAX2ZHZkDzn4xV3hKqroAA7oWYoPZUKCS1wnQAQNKzeEddCzEkOrZVG5zax4686NYi+xe6qjLnZQoG+a4wEMeZ151r+Tngk3baNf0buA4hEfQXcLbXTTXIQ3jOorzXieD6m69qQTbYrI2JUxpXoHDOHML2HeCbiqVCrrlgHLPLcH3V53cuhmbNo8nMDvmnXXnrWnFo58+2mjtvg911z9hUJIVndUzkbhMx1j3VDiMM9s5XUqeXiDzBGhHiKv9KG7dhR7K4e1lH4lLE+pJpmCbPhryN/wilxD3Z3Ft18jmUx3rSsVxjtLsHxEfCrFp22mq49ketS28Rycx5DegyV0WurbvrtQ/SU7zSoGsLX8T9aY5xI8qJWcZoIPr+flWTe6zPPgAdaMYNyD4nw3jkByUc67oTtnLKOjV43gjYzBqoYC4rMyFtpJIKGOUaT4CvMSWtuR9pSV0MiVMHzEivR8Vxn6PgCUPbdiiTM9rUtpzAJNebR31CfuLw6Rp+iNqziLr28QBmdew0kQRqQPE0buMMC5CJKr7TZg0HuYHUH9awFpypBBgjUEd9THFl3z3CW7/GoSjbOmGSl+zctf+kXVuGSWIygCeyAfz+dScWsmxdtPDDP1jEER2ZXL8u6rvAbK5UzXXQKqyiEW0UuqwC+7EEkHyqXinFsDcd1z3ZVVtILbl5VdSwWO8b+NW41E7Mc1ySS3/ILxOBa1iTeTMiPJAIMBipJE+ZkR30L6RYkpdVCpAtNkkfacqC0ev9a1qHC5Rbs/Si+jK14obYZY1ZZLFZAEATXLWGsqrC8n0pwrszok5WdgGftDsxOmkwNKP419glHbfVb2Y6xxC47KAhkMNz485860XCeGQireiFR2yrIBjO+41M+lRY7CJbxCIga2FE/WIQkmIOfdtTG1Wg7G5kdgAyvbBA07QZJ15SwpFFxZaCi43ZFxV0tW0VRlBtB+6WeZmNTyAkms3wy0roQSBGonbWPzmtBjcOHw9lwjFlU2mJ0AK+zJbfsyaydhnR8iusk5TGsAHQ+6tkX0ckm5NWW2IAidap4u+1vLpJYZgWGkaifGrl9O2kOjSV9pGAbXUGOWlaYp1t4sy2lZLdtYSSuizz1B12qNcdsvh8NLLKroznRIZrjm4LlxEQtltt2lOZRmHgJ28fCvUMBgkcK9ohwtkqqtpcBckAkHfmOVBcQ4S2kAAu6pIgR2HMz3SBV+xiVa0rsM4ZmyupKvktgKDI31k6g1bE13Q+Tw/lLjduwLjOGEXnZSyGcoVhyELA9e6gXSPhly6t64Iy4VbYgfbRyZee8HWO6tlg7rOg+tZkM9m4JcEzBRhoYJB1jasrx7it+272kKZbqKtyQCWBU+B5NyppK9ohmbjCnozHCLsEjXtAiBuftR7wKMcKtf7zYNwNlLI8KO0cjSNPMChHDEVL6guMquO1BErmykx5GYrWYfEoH7AcBOxnaQXU9wPsrAHvpUqTYMPqaTYexeMc3LWZyiQCtu2YcSpHbfmdDIE1gMdwJ7vELliyhLOzMoYjQMuftEwOe9aV8UpNsKQWR7ls5TroSwM8+yaix9q79Ot3kS4QUQutvMrMstIzKdJAjflTtSkhfERio2jMYDCPduFbq5mtKykOxQKluQQSAT2dhHf4UY4zw4IhsWFCpBZjIZrlxGGZHaPsBgQBoYnnp3iV5rIR/ozpN24xuXJJa3eGXq3bc6ZjJNEMThWZMQJ1abqwfZZlNt4PdJQ/w0i06YMUeeFyj2uzEWFlCOdNRgdDV/HYUq06AsA2h0J0kjunf1qhiU+0PWlkqdHGnZzInj7qVQdZSrUEucPIzE8/GjSEbzmPMj4KByFA+EsMxmD51oXxHZp/OcdJGjgUttg7iC3L2VBskkKTuzbnzgAelBrtsqYYEHx3rR4C5JY+P5UP41eDEL3VLm5S2UlijGNoECpEWWHnUZqbCIWdQBJJ5eRp2Tj2g9w1RfuzdYsi9vqw2UMBACeHcfAVquFHDKT1bXbas0nW3Cke0dDqoAOgnbwrFiwUQnZmA9xOg9w+NOa48KivyIjzkH5mm5JKjrxXGVtG7w3Se1au5mv5ydyEVYk9lII2VconvmguP6TBnVg5hhcRwvZBDAlfZ8/hWcxKqjkZAwO0k6RvtUzXlKA5EWHRiADIEkHUtPOhzaZW3JNBbifH0uO5CuwCKFzEkSNZAJ56e6qdrjbhVZQinTtEEkch8pqncs5Rq2QiIk7g7CN/XaqeLug9lZAE7gAydSNOU6+tLKTbBF8VbDeL4oHz9Y7ulzt/cRbnPsrv8ACgBxK5wVGX8I5T3VArMezOlEbGD7cFk/d5tWga8vxeFbb7JylfQutUvZ17sxjxPdWjwWIW0bjuQAX6uAZIca+6PHlQLD4bMyAvbJDLEMNRnA+W/lW74v0a6zD3ittA4ZLgysNSbeu/jR4KXZ0YM8sS5IDcY4glzJa7WQlgx00JEKQddu+q2KxV2xNhD1iCUtMSFOQ9oyNswmg2HwvWJKsQyakE8wdhO9GMVcCJZLkkXCd4OwAJkbHUe+glXRR5Hlbk9dGp6L3FKK9x2GQg6ozLlDrMtv38qyXSm+HxV3KQVVsgI2PVgJPqRWh4XgGSCmICIWWWJgFPaMkHvCjbnWP4lcTrHZSArMxAnaTtHL9IqsHrZx+OjSVMFucrk940/rzo0iXb/adic8GM2pOi6k7+lC7gVtJBPITr4iiuE4poAoFsRl7Cl3JGvtEgCpypMHhZN6NRwnh6WbjZuwue2683Ie22w3351H0lxQXqHXrUK57bFwUnmCMu+ub31QsYoi6jpnB6tgWuNmb6t83Zj2dGAq10txIeyxzsWRluQdyrLlOknaZ99UjNUVz4qi1/wy3GsSHAhywGgnNoIPf6c+VaXhfErBxCFldlZbdthMCbg7ca7QF171PnWJuPmHZVj/AAn9KNjC3EuwiOVLoRCsQEKFhy5SPdSyackc/heUYyXwy10nykoUtNaABQKxJJCwA3hI5axFY/EtDEA+f6VquM4K+952S07hiGBCwO0A0SY1BJHpQLiXDmUBmQowOR0OsNEq2nJh7iPGs2pPRBwcW0CqVT9QaVAUJFre4YT4qPmIrrYsRBE+TH8xVB1CgSRJ10IOnpsfCml6FBTaLX0qNEzDziqzNPtNr5T8q6qknSudQx7vUgfM0EkFybOPaPIg+RE+4wadhLr23RxmUqdDBETpPuNcxtuGUeFXfoFvqw632VuaFG11I7JGnvo2ZXei5j+Io3sq6ktOWJAAEAK06iiHCuCYhslxLFx012ydoEMCQc0aUCw75dj5k77fCtNwXFulhcjlQS0xpOvOKlKVbO3G5Sf7IMf0ZxeaDby/xL8SxkmO7uqqOjOJ2z21/FdXbuijivmjNrG06xU1y4wgBjpOxIGvlSebeyzw7Adnos+zXrGo2LlvWBTm6ISBOKQ+SO3yoosnczT2UwPU/Gl81h8lAm10RtA9rEExvFp6vjgeGEnNMqF/dnSI7Qlt6lM10xQeWQViilVEdvhOFXfN/InfOmsii9m5hlzQh7QtgzI/d+z9vwoXFOK+G1FZpfY3CNUOwmCw9tzct9crEk+0uXXlBnSr2OuWriIjoSqHOplQQxEHVR3DaqoJ0pFvCh5kjKKSpCbC4bsnqmOQyO2YBBmYAjeoHwWGJk4VCTzLsfyqTNpTjyoeZIzgn2RLYw6wVw1kH8JNTC8oXs2rK+Vv/wC6jY0iNKVzYYwS6JRjmA0CDyRad9PeNHjyRB/21Aiz3VKQBEVuTDxQ5cbc5u3+UfIU/wCkud3f+dv1qEH5VGz8hzo8gKKJVxLgEF2PqfzoL0ilOrdz2LodGI1YHTK0cypUH08aJusR8aZjeFYjFoi5G6u37ByMQ0zJBA21j0quF+o5/FKomR/sx/8AxFn/ANw/pXK0X+xF/wD5X+W7Srt0ecY4Oe8++udZ4/Gva1wvDV1C4Rf4LQ2PiJp307h6/bwo8hb/ACFTox4jmnn4b11LDk9kGe/kI5zsK9a430tw9ns2gtx/ABVHmY38BXn3FOK3sQ2a45Pco0UeQpZNIeMG+yrfVJU+0QoB+7Ma+fOonY7zTitR1NssopdDkNaThKnqF00zPrr4elZpd603BHPUqNN3/wA0Ckn0WwXyCKTliad68qZ8qdUEdrC/AuCtiCwVlXKASWPeYo/iOilkL++OaIBJXLMd3dJof0UIFnFiJm3G+uz1nctVuMYq0crU5zaTqgtxDgL21LAq6KdWUzG+/uoSBR3oxd7bo0lXRwR3EDfTag4FTklSaKwcral8E/D+HPezlB7Clj5AHbx0qsj6mtt0eyWcOhffEXAgG3ZMrPukz5VmOMYDqbzoBADHLP3Z09P0p5Q4xTEhk5Tcf8KyqWICgk9wBJ7thVv+yMQNepePLXbu3q70cfImJcAFlt6THfO3MSBVMcaxObP1ryeU9nyyezHpQSikmwuU3JpVoHshBIIgjedDp3zUliyztlRSzHYATRhyuKV2ICX0GYkTDqBr2eRpcJusmHvOuhDpB5g5Tyg99FRV/ozyPj1sr/7OYgj2BtmiQTEwdBzofjMDctSHQrrpOxiDoee4qx9PvA5heuAnmHf9aK8P4j1w6jEAOH9hyO0rliQSZjmffQSi9IzlOKt00Zu2hJA5/nU+OwjW3KOAGETz3E8vCrFjD5LyqRqrhTtyePKrfSm2RibmgGq7CN1H5zQ4+lsPP1JfoBxXLixTyKaaSy1DTtRLD9OsNh0W01u4zoIYqEgmZ0JPjQ1QRrWM4ufrn/F+VWwPZyeL9qPR/wD+nYb/AMPd99v9aVeWUq6rZ5xUT+vcKv8ACf3g8j/ppUqVhXZaxftt5/kKhpUqRnShwqA712lWMcTetRwX90nm3zFdpUk+iuH3BD+vjThtSpVA7Waboh7OK/6R+T1n/wBBSpU2T2ojD/0kE+C+ze/6Z/1rQxeXmKVKh+KD+UjZ9Iv3eC9PlboZ0x/vLfhH50qVWye05sXvRFwj9zivwD5PQc8q7SqL9qOiHukFujf79fw3P9DU/Df3O7+Nf9ApUqpHolL3Ak/18Ku8M/fWvxp/qFKlUodl5+0fif7y3/V/7qn6V/3i55J/oWlSqn4sivev4AD7iuNSpVA6zh29axPFv3z/AIjSpV0Yezj8Z7UVKVKlXWecf//Z">
                <p>PYT gave us so much attention and support to make sure we had a great vacation! <span> - Prannoy,
                        Trip to Switzerland</span></p>
            </section>

        </div>
    </div>

        </div>
    </div>
</div>
    <div class="col-md-4 "></div>
<!-- Remove the container if you want to extend the Footer to full width. -->
<footer class="text-white text-center text-lg-start" style="background-color: #23242a;">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">About company</h5>

          <p>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
            voluptatum deleniti atque corrupti.
          </p>

          <p>
            Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas
            molestias.
          </p>

          <div class="mt-4">
            <!-- Facebook -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-facebook-f"></i></a>
            <!-- Dribbble -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-dribbble"></i></a>
            <!-- Twitter -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-twitter"></i></a>
            <!-- Google + -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-google-plus-g"></i></a>
            <!-- Linkedin -->
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4 pb-1">Search something</h5>

          <div class="form-outline form-white mb-4">
            <input type="text" id="formControlLg" class="form-control form-control-lg">
            <label class="form-label" for="formControlLg" style="margin-left: 0px;">Search</label>
          <div class="form-notch"><div class="form-notch-leading" style="width: 9px;"></div><div class="form-notch-middle" style="width: 48.8px;"></div><div class="form-notch-trailing"></div></div></div>

          <ul class="fa-ul" style="margin-left: 1.65em;">
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">New York, NY 10012, US</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">info@example.com</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">+ 01 234 567 88</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-print"></i></span><span class="ms-2">+ 01 234 567 89</span>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Opening hours</h5>

          <table class="table text-center text-white">
            <tbody class="font-weight-normal">
              <tr>
                <td>Mon - Thu:</td>
                <td>8am - 9pm</td>
              </tr>
              <tr>
                <td>Fri - Sat:</td>
                <td>8am - 1am</td>
              </tr>
              <tr>
                <td>Sunday:</td>
                <td>9am - 10pm</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>


  </body>
</html>



