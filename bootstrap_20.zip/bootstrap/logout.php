<?php
session_start();

session_unset();

$message = "You have been logged out.";
$_SESSION['logout_message'] = $message; // Store the message in a session variable

header('Location: https://www.psd2htmlx.com/w/bootstrap/bootstrap/sign-in.php');
exit();
?>
