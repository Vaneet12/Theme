<?php
session_start();
$userprofile=$_SESSION['username'];
if($userprofile==true){

}
else{
    header('location:sign-in.php');

}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://kit.fontawesome.com/1b5688f48a.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="tour.css">
    <script src="java5withyou.js"></script>

</head>
  <body>
  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 text-secondary">Home</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Features</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Pricing</a></li>
          <li><a href="#" class="nav-link px-2 text-white">FAQs</a></li>
          <li><a href="#" class="nav-link px-2 text-white">About</a></li>
        </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>

        <div class="text-end">
        <a href="logout.php" class="btn btn-outline-light me-2">Logout</a>
          <a href="profile.php" class="btn btn-warning">Profile</a>
        </div>
      </div>
    </div>
  </header>

<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/main.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.psd2htmlx.com/w/bootstrap/home.php"  class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                        
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Orders</span></a>
                    </li>
                    <li>
                        <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                            <i class="fs-4 bi-bootstrap"></i> <span class="ms-1 d-none d-sm-inline">Bootstrap</span></a>
                        <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 2</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#submenu3" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Products</span> </a>
                            <ul class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 2</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 3</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 4</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Customers</span> </a>
                    </li>
                    <li>
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/index1.php" class="nav-link px-0 align-middle">
                         <span class="ms-1 d-none d-sm-inline">Tour & Travel</span> </a>
                    </li>
                </ul>
                <hr>
                <div class="dropdown pb-4">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30" class="rounded-circle">
                        <span class="d-none d-sm-inline mx-1">loser</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                        <li><a class="dropdown-item" href="#">New project...</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/profile.php">Profile</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/logout.php">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col py-3">
        <div class="swit_submain1">
    <div class="text_div">
      <b>PLANNING YOUR TRIP TO</b>
    </div>
    <div class="switzerland">
      <div>
        <span id="desti"></span>
        <span id="test"></span>
        <span id="travelmode"></span>
        <span id="duration"></span>
      </div>

      <a target="_self" href="/">
        <i class="fa fa-times" aria-hidden="true"></i>
      </a>
    </div>
    <div class="progress_div">
      <span class="yellow"></span>
      <span class="yellow"></span>
      <span class="yellow"></span>
      <span class="yellow"></span>
      <span class="grey"></span>
      <span class="grey"></span>
    </div>
    <section class="when_to">
      <h1>Who is travelling with you?</h1>
    </section>
    <div class="travelling">
      <div class="stay_travelling">
        <div>
          <label onclick="pageRedirect('Couple')">
            <span class="travel"><img style="max-width:100%"  src="https://www.psd2htmlx.com/R/multistep/images/couple.png"></span>
            <p>Couple</p>
          </label>

        </div>
      </div>
      <div class="stay_travelling">
        <div type="button"
          style="background: transparent; border:1px solid white; color: white; border-radius: 7px; width: 100%"
          class="btn" data-toggle="modal" data-target="#exampleModal">
          <label>
            <span class="travel"><img style="max-width:100%" class="tra_img"  src="https://www.psd2htmlx.com/R/multistep/images/family.png"></span>
            <p>Family</p>
          </label>

        </div>
      </div>
      <div class="stay_travelling">
        <div type="button"
          style="background: transparent; border:1px solid white; color: white; border-radius: 7px; width: 100%"
          class="btn" data-toggle="modal" data-target="#exampleModal1">
          <label>
            <span class="travel"><img style="max-width:100%" class="tra_img" src="https://www.psd2htmlx.com/R/multistep/images/friends.png"></span>
            <p>Friends</p>
          </label>

        </div>
      </div>
      <div class="stay_travelling">
        <div>
          <label onclick="pageRedirect('Solo')">
            <span class="travel"><img style="max-width:100%"  src="https://www.psd2htmlx.com/R/multistep/images/solo.png"></span>
            <p>Solo</p>
          </label>

        </div>
      </div>
    </div>
  </div>




  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="margin-top:30%">
        <div class="modal-body" style="width: 100%;">
          <div class="Family_friends1">
            <div class="friends_detail1">
              <span style="font-size: 16px;">Room</span><input id="rrom" value="1"></input>
            </div>
            <div class="persons">
              <i class="fa fa-minus minu" onclick="decrease_adult(event)" aria-hidden="true"></i>
              <input id="incre_ad" class="input_in1" value="2"><span class="perspan">Adult</span>
              <i class="fa fa-plus minu" onclick="increase_adult(event)" aria-hidden="true"></i>
            </div>
            <div class="persons">
              <i class="fa fa-minus minu" onclick="decrease_child(event)" aria-hidden="true"></i>
              <input id="incre" class="input_in1" value="0"><span class="perspan">Child</span>
              <i class="fa fa-plus minu" onclick="increase_child(event)" aria-hidden="true"></i>
            </div>
            <div class="room_d">
              <span class="remove_room" onclick="deleteRoom(event)">
                <i class="fa fa-minus" aria-hidden="true"></i> &nbsp; Delete Room
              </span>
              <span class="add_room" onclick="addRoom(event)">
                <i class="fa fa-plus" aria-hidden="true"></i> &nbsp; Add Room
              </span>
            </div>
            <div class="result">

              <button class="anchor_left1" data-dismiss="modal">Close</button>
              <button class="anchor_right1" onclick="family()">Done</button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="margin-top:30%">
        <div class="modal-body" style="width: 100%;">
          <div class="Family_friends1">
            <div class="friends_detail1">
              <span style="font-size: 16px;">Room</span><input id="friendRoom1" value="1"></input>
            </div>
            <div class="persons">
              <i class="fa fa-minus minu" onclick="friendAdultDec(event)" aria-hidden="true"></i>
              <input id="friendAdd" class="input_in1" value="2"><span class="perspan">Adult</span>
              <i class="fa fa-plus minu" onclick="friendAdultInc(event)" aria-hidden="true"></i>
            </div>
            <div class="persons">
              <i class="fa fa-minus minu" onclick="friendChidDec(event)" aria-hidden="true"></i>
              <input id="friendchild" class="input_in1" value="0"><span class="perspan" >Child</span>
              <i class="fa fa-plus minu" onclick="friendChildInc(event)" aria-hidden="true"></i>
            </div>
            <div class="room_d">
              <span class="remove_room" onclick="removeRoom(event)">
                <i class="fa fa-minus" aria-hidden="true"></i> &nbsp; Delete Room
              </span>
              <span class="add_room" onclick="extendRoom(event)">
                <i class="fa fa-plus" aria-hidden="true"></i> &nbsp; <span>Add Room</span>
              </span>
            </div>
            <div class="result">

              <button class="anchor_left1" data-dismiss="modal">Close</button>
              <button class="anchor_right1" onclick="friend()">Done</button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>


  </div>
  </div>
        </div>
    </div>
</div>
    <div class="col-md-4 "></div>
<!-- Remove the container if you want to extend the Footer to full width. -->
<footer class="text-white text-center text-lg-start" style="background-color: #23242a;">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">About company</h5>

          <p>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
            voluptatum deleniti atque corrupti.
          </p>

          <p>
            Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas
            molestias.
          </p>

          <div class="mt-4">
            <!-- Facebook -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-facebook-f"></i></a>
            <!-- Dribbble -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-dribbble"></i></a>
            <!-- Twitter -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-twitter"></i></a>
            <!-- Google + -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-google-plus-g"></i></a>
            <!-- Linkedin -->
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4 pb-1">Search something</h5>

          <div class="form-outline form-white mb-4">
            <input type="text" id="formControlLg" class="form-control form-control-lg">
            <label class="form-label" for="formControlLg" style="margin-left: 0px;">Search</label>
          <div class="form-notch"><div class="form-notch-leading" style="width: 9px;"></div><div class="form-notch-middle" style="width: 48.8px;"></div><div class="form-notch-trailing"></div></div></div>

          <ul class="fa-ul" style="margin-left: 1.65em;">
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">New York, NY 10012, US</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">info@example.com</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">+ 01 234 567 88</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-print"></i></span><span class="ms-2">+ 01 234 567 89</span>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Opening hours</h5>

          <table class="table text-center text-white">
            <tbody class="font-weight-normal">
              <tr>
                <td>Mon - Thu:</td>
                <td>8am - 9pm</td>
              </tr>
              <tr>
                <td>Fri - Sat:</td>
                <td>8am - 1am</td>
              </tr>
              <tr>
                <td>Sunday:</td>
                <td>9am - 10pm</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
  </body>
</html>

