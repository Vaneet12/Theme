<?php
session_start();
include("connection5.php");
$userprofile=$_SESSION['username'];
if($userprofile==true){

}
else{
    header('location:sign-in.php');

}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://kit.fontawesome.com/1b5688f48a.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <!-- bootstrap5 dataTables css cdn -->
    <link
      rel="stylesheet"
      href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css"
    />
    <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

<style>
  .text-secondary.font-weight-bold.text-xs{
    text-decoration:none;
  }    
  a.bi.bi-trash3.delete-item {

        color:red;
    }
.delete{
  cursor:pointer;
}
  #wrong_pass{
    color:red;
  }
  #wrong{
    color:red;
  }
.see{
  border-radius: 35px;
    padding: 0 25px;
    height: 50px;
    margin: 0;
    display: block;
    float: none;
    width: 100%;
    background: #0E0E0F;
    font-weight: 500;
    color: #FFF;
    border: solid 1px #0E0E0F;
    outline: 0;
    font-family: Klarna Text,Helvetica Neue,Arial,Helvetica,sans-serif;
    font-size: 16px;
    cursor: pointer;
margin:20px 10px 10px 1px;
}
.toast {
    position: fixed;
    top: 20px; /* Adjust this value to change the vertical position */
    right: 20px; /* Adjust this value to change the horizontal position */
    z-index: 11; /* Ensure the toast container appears above other elements */
    color:white;
    padding: var(--bs-toast-padding-x);
  word-wrap: break-word;
  }
 

</style>
<script>
    $(document).ready(function() {
    // Add a click event handler to the delete buttons
    $(".delete-item").click(function(e) {
      e.preventDefault(); // Prevent the default behavior of the link
      
      // Get the item ID from the data attribute
      var itemId = $(this).data("item-id");
      var button = $(this);

      
      // Make the AJAX request to delete the item
      $.ajax({
        url: 'delete3.php?id=' + itemId,
        type: "GET", // or "POST" if applicable
        success: function(response) {
          // Handle the success response (e.g., show a success message)
          console.log("Item deleted successfully!");
          button.closest('tr').remove();
          showToast("Item deleted successfully!");

        },
        error: function(xhr, status, error) {
          // Handle the error response (e.g., display an error message)
          console.log("An error occurred while deleting the item.");
        }
      });
    
    });
  });
  function showToast(message) {
  // Create a new toast element
  var toast = $('<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">')
    .addClass('toast-success')
    .text(message);

  // Append the toast to the body
  $('body').append(toast);

  // Initialize the toast
  toast.toast({ delay: 3000 }); // Set the desired delay for the toast to be shown

  // Show the toast
  toast.toast('show');

  // Remove the toast after it is hidden
  toast.on('hidden.bs.toast', function() {
    toast.remove();
  });
}

</script>
</head>
  <body>
  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 text-secondary">Home</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Features</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Pricing</a></li>
          <li><a href="#" class="nav-link px-2 text-white">FAQs</a></li>
          <li><a href="#" class="nav-link px-2 text-white">About</a></li>
        </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>

        <div class="text-end">
        <a href="logout.php" class="btn btn-outline-light me-2" onclick="toast()">Logout</a>
          <a href="profile.php" class="btn btn-warning">Profile</a>
        </div>
      </div>
    </div>
  </header>
  <div class="toast-container">
</div>
<div class="container-fluid mt-2">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">Menu</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/main.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="#submenu1" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Users</span> </a>
                       
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Orders</span></a>
                    </li>
                    <li>
                        <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                            <i class="fs-4 bi-bootstrap"></i> <span class="ms-1 d-none d-sm-inline">Bootstrap</span></a>
                        <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 2</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#submenu3" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Products</span> </a>
                            <ul class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 1</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 2</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 3</a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Product</span> 4</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">Customers</span> </a>
                    </li>
                    <li>
                        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/index1.php" class="nav-link px-0 align-middle">
                        <i class="fas fa-suitcase-rolling" style='font-size:24px'></i> <span class="ms-1 d-none d-sm-inline">Tour & Travel</span> </a>
                    </li>
                </ul>
                <hr>
                <div class="dropdown pb-4">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30" class="rounded-circle">
                        <span class="d-none d-sm-inline mx-1">loser</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                        <li><a class="dropdown-item" href="#">New project...</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/profile.php">Profile</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/logout.php">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col py-5 ">
        <center><h2>Student Information</h2></center>
        <?php

$query="SELECT * FROM `student`";
$data=mysqli_query($con,$query);
$total= mysqli_num_rows($data);

if($total !=0){
    ?>
        <div class="container mt-4">
        <table  id="datatable" class="table table-striped nowrap" style="width:100%">
    <thead>
      <tr>
      <th >Id</th>
        <th >Users</th>
        <th>Contact-details</th>
        <th>View</th>
        <th>Delete</th>
        <th>Edit</th>

      </tr>
    </thead>
    <?php

  while($result=mysqli_fetch_assoc($data))
  {
    echo "<tr>
    <td>
      
        <h4 class='mb-0 text-sm'>".$result['id']."</h4>
  </td>
    <td>
      
        <h6 class='mb-0 text-sm'>".$result['name']."</h6>
        <p class='text-xs text-secondary mb-0'>".$result['email']."</p>
  </td>
  <td>
    <p class='text-xs font-weight-bold mb-0'>".$result['phone']."</p>
    <p class='text-xs text-secondary mb-0'>".$result['address']."</p>
  </td>
  <td >
    <span class=''><a  class='white btn btn-success rounded' href='view.php?id=$result[id]'>View</a></span>
  </td>
  <td>
  <button class='  toast-btn ' type='button' data-target='successToast'>
  <a class='bi bi-trash3 delete-item'  href='delete3.php?id=$result[id]' data-item-id='$result[id]' onclick='myFunction()'></a>
  </td>
 </button>
 <td > <a  href='edit.php?id=$result[id]' class='text-secondary font-weight-bold text-xs' data-toggle='tooltip' data-original-title='Edit user'>
  Edit
</a></td>

</tr>";

  }
}
else{
    echo "no records found";
}
?>
  </table> </div>    </div>
    </div>
</div>

<script>
function myFunction() {
  var x = document.getElementById("snackbar");
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
</script>

<!-- Remove the container if you want to extend the Footer to full width. -->
<footer class="text-white text-center text-lg-start mt-2" style="background-color: #23242a;">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">About company</h5>

          <p>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
            voluptatum deleniti atque corrupti.
          </p>

          <p>
            Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas
            molestias.
          </p>

          <div class="mt-4">
            <!-- Facebook -->
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fa-brands fa-facebook-f"></i></a>
            <!-- Dribbble -->
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-dribbble"></i></a>
            <!-- Twitter -->
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-twitter"></i></a>
            <!-- Google + -->
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-google-plus-g"></i></a>
            <!-- Linkedin -->
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4 pb-1">Search something</h5>

          <div class="form-outline form-white mb-4">
            <input type="text" id="formControlLg" class="form-control form-control-lg">
            <label class="form-label" for="formControlLg" style="margin-left: 0px;">Search</label>
          <div class="form-notch"><div class="form-notch-leading" style="width: 9px;"></div><div class="form-notch-middle" style="width: 48.8px;"></div><div class="form-notch-trailing"></div></div></div>

          <ul class="fa-ul" style="margin-left: 1.65em;">
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">New York, NY 10012, US</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">info@example.com</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">+ 01 234 567 88</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-print"></i></span><span class="ms-2">+ 01 234 567 89</span>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Opening hours</h5>

          <table class="table text-center text-white">
            <tbody class="font-weight-normal">
              <tr>
                <td>Mon - Thu:</td>
                <td>8am - 9pm</td>
              </tr>
              <tr>
                <td>Fri - Sat:</td>
                <td>8am - 1am</td>
              </tr>
              <tr>
                <td>Sunday:</td>
                <td>9am - 10pm</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>


  
<!-- End of .container -->
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script>
      $(document).ready(function () {
        $('#datatable').DataTable();
      });
    </script>
  </body>
</html>
