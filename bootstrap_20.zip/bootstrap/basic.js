function pageRedirect(event) {
    localStorage.setItem('destination', event)
    window.location.href = "https://www.psd2htmlx.com/w/bootstrap/bootstrap/destination.php";
}