-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 20, 2023 at 02:28 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `responsiveform5`
--

-- --------------------------------------------------------

--
-- Table structure for table `multi`
--

CREATE TABLE `multi` (
  `id` int(11) NOT NULL,
  `desti` varchar(255) NOT NULL,
  `test` varchar(255) NOT NULL,
  `travelmode` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `withyou` varchar(255) NOT NULL,
  `fordo` varchar(255) NOT NULL,
  `passenger_name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `multi`
--

INSERT INTO `multi` (`id`, `desti`, `test`, `travelmode`, `duration`, `withyou`, `fordo`, `passenger_name`, `phone_number`, `email`) VALUES
(199, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(200, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(201, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(202, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(203, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(204, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(205, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(206, 'Dharamshala', '7', 'Aeroplan', '8-10 days', 'Solo', 'A bit of everything', '', '', ''),
(207, 'Dharamshala', '13', 'Train', '10-12 days', 'Solo', 'A bit of everything', '', '', ''),
(208, 'Dharamshala', '13', 'Train', '10-12 days', 'Solo', 'A bit of everything', '', '', ''),
(209, '', '', '', '', '', '', '', '', ''),
(210, 'Dharamshala', '1', 'Train', '10-12 days', 'Solo', 'A bit of everything', '', '', ''),
(211, 'Dharamshala', '1', 'Train', '10-12 days', 'Solo', 'A bit of everything', '', '', ''),
(212, 'Dharamshala', '1', 'Train', '10-12 days', 'Solo', 'A bit of everything', 'Jescie Davenport', '666-9999-555', 'koduso@mailinator.com'),
(214, 'Manali', '6', 'Train', '10-12 days', 'Solo', 'Art & Culture', '', '', ''),
(215, 'Manali', '6', 'Train', '10-12 days', 'Solo', 'Art & Culture', '', '', ''),
(216, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(217, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(218, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(219, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(220, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(221, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(222, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(223, 'Dharamshala', '6', 'Aeroplan', '5-8 days', 'Couple', 'A bit of everything', '', '', ''),
(224, 'Dharamshala', '21', 'Car', '3-5 days', 'Couple', 'Art & Culture', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `multi`
--
ALTER TABLE `multi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `multi`
--
ALTER TABLE `multi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
