function setDuration(event) {
    localStorage.setItem('days', event)
    window.location.href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/with.php";
}

window.onload = function(){
    let showdata = localStorage.getItem('day')
    let showmonth = localStorage.getItem('MonthName')
    let fulldate =showdata + " " + showmonth;
    document.getElementById('test').innerText = fulldate;

    let godesti = localStorage.getItem('destination')
    document.getElementById('desti').innerText = godesti;

    let gomode = localStorage.getItem('modeOfTravel')
    document.getElementById('travelmode').innerText = gomode;
}