<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("connection6.php");

$el1 = '';
$el2 = '';
$el3 = '';
$el4 = '';
$el5 = '';
$el6 = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // Get the JSON data from the request
  $jsonData = file_get_contents('php://input');

  // Decode the JSON data into a PHP associative array
  $data = json_decode($jsonData, true);

  // Get the values from the decoded JSON data
  if (isset($data)) {
    $el1 = $data['desti'];
    $el2 = $data['test'];
    $el3 = $data['travelmode'];
    $el4 = $data['duration'];
    $el5 = $data['withyou'];
    $el6 = $data['fordo'];
    
    

    // Perform any necessary data validation or sanitization

    // Prepare and execute the SQL query to insert the data into the database
    $query = "INSERT INTO `multi` (desti, test, travelmode, duration, withyou, fordo, passenger_name, phone_number, email) 
              VALUES ('$el1', '$el2', '$el3', '$el4', '$el5', '$el6', '$passengerName', '$phoneNumber', '$email')";
    $result = mysqli_query($con, $query);

    // Check if the query executed successfully
    if ($result) {
      // Data stored successfully
      echo "Data stored in MySQL database.";
    } else {
      // An error occurred
      echo "Error: " . mysqli_error($con);
    }

    // Close the database connection
    mysqli_close($con);
  }
}
?>
