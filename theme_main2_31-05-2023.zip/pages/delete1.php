<?php
include ("connection4.php");
$id= $_GET['ID'];
$query="DELETE FROM user WHERE ID='$id'";
$data=mysqli_query($con,$query);
if($data)
{
    $response = array('success' => true);



}
else{
    $response = array('success' => false);
}
header('Content-Type: application/json');
echo json_encode($response);

$con->close();
?>