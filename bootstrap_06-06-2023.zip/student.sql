-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 06, 2023 at 01:38 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `responsiveform5`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `password`, `cpassword`, `phone`, `address`) VALUES
(1, 'vaneet', 'vaneet@ocode.co', '$2y$10$z.7p36c2X.GAqVSXgdFzQ.oU0C.ySZw9zila/5SAykN0qasBgM2Vy', '$2y$10$kq9BbIMfUzVx2Cf7xBOFnOJ60jfH0oT1zNzuHVEHGH.WIlRySioVO', '6283951020', 'Una deoli gagret'),
(2, 'Bunty', 'tagijufa@mailinator.com', '$2y$10$QYVL3SphC/jWVxX6Tp2ao.ts2YidV2Ek37B4/e8oz8ac/oEz8oB2W', '$2y$10$5Px6YMi1v4kJa2XmHWsvouK0P1Isns0YQ0HyOd4MbFOzn7RMdtpkm', '2547254325', 'qefegegyr@mailinator.com'),
(3, 'dinurene@mailinator.com', 'pabiqocene@mailinator.com', '$2y$10$7B/26qhWNETkG7G0/Wvbm.DPVZqiy3JD/XHiJEKWP8ewqKmhb0p76', '$2y$10$8kQYNHS/CR7bSd1HQGl/EeEXvZ.T.oSfvan3dELzfqCIF.fsBT8Ti', '7586387568', 'woxo@mailinator.com'),
(4, 'gylo@mailinator.com', 'desytejyq@mailinator.com', '$2y$10$MLSi6AKsAOM.Re2gw06iv.HgZC.44uXeSbBaS66GYacXrUr1z.3lW', '$2y$10$6U68uVuwlZ1X8GB1Lp8nIeJuLa.9L0lCUutKhY6.CCrqEvQBREWqW', '7853654353', 'zajiwolik@mailinator.com'),
(5, 'rishu', 'rohan12@gmail.com', '$2y$10$CFnwapu8gsh2uOHP656wYuGIBB4fE/LzkdxaUp3RVUvOqNj74eGAW', '$2y$10$pXWT.LVyYKUgT8.0gCvYLudAvhntNMSAQh5tkTDEU7cSZ.m3JaJGW', '5436543535', 'hoshiarpur punjab'),
(6, 'vodaxil@mailinator.com', 'xyriny@mailinator.com', '$2y$10$A9SlRD/HdaLhSpAECIjENer1ewXoCx.PGVhcUKdVrarn7JQgColzy', '$2y$10$TXRc4946I1QNQ8V7sqqYqukl/Cn7R.jmf7ZWTuqCR.lCJT77DRqEK', '2536583535', 'xawatere@mailinator.com'),
(7, 'hifoduhano@mailinator.com', 'furu@mailinator.com', '$2y$10$PvG58C47e5oUCTPBqGqQOuP.3iQQUal3wkNCxRNpZU1LlAMNggZMi', '$2y$10$CAd5oABcoA/AykAgAUSozOOC1E2KeFpsQL7oPkytK7YAdCIh2yeyu', '8963985989', 'pasuba@mailinator.com'),
(8, 'jimezyki@mailinator.com', 'vyparuzob@mailinator.com', '$2y$10$KCJZbOsnchlAy7E9vmnlmeoloYiVbB6Oi8PT1f7p5ji9oFqSX83pO', '$2y$10$vFKSayFgTSaDlkHLRgIK0OIEUX82v61F3NfsIQRjGDizusz4zAufC', '5873654765', 'kadygireju@mailinator.com'),
(9, 'cygucoxypu@mailinator.com', 'duqekuxu@mailinator.com', '$2y$10$nqaVrJGhm6a45u9tJ81rr.Y95SlsDlKdzNtkRlR.TN6sUT6M6lWhK', '$2y$10$k1sY9U8.jirb9rQTg6fML.lxJl30gsE1yQA2mbUd/iq70n2MT3wOS', '7586358765', 'kusidomecu@mailinator.com'),
(10, 'xynodi@mailinator.com', 'kohab@mailinator.com', '$2y$10$K4I4aVzBgMhYaagTythvr.bqnMrx856F/90Dnj/sb260Ey2cl.Owa', '$2y$10$FN.gZVyqfl8ipU.cZXDPgeso9oPdtwWYunNP.v1amL2OC97jiek3S', '8768756876', 'mojivepe@mailinator.com'),
(11, 'hyluvusoh@mailinator.com', 'mohilivepu@mailinator.com', '$2y$10$niHETs8VnYksdSWD7poLRevJxm986vx6Nxamahhxez0huRgubzCdu', '$2y$10$EXI21ZGX499mLE9aWPr/..m84eUd4FfkSmyRpYTCEWVDr9NRB3wRi', '8969868969', 'suzena@mailinator.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
