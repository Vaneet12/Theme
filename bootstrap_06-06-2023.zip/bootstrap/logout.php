<?php
session_start();


session_unset();

header('location:https://www.psd2htmlx.com/w/bootstrap/bootstrap/sign-in.php');

?>