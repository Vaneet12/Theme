<?php

ob_start();
session_start();
include("connection5.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$passErr=$emailErr="";
if(isset($_POST['submit'])){
  
  $name=$_POST['name'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  $cpassword=$_POST['cpassword'];
  $phone=$_POST['phone'];
  $address=$_POST['address'];

 $password1= password_hash($password, PASSWORD_DEFAULT);
 $password2= password_hash($cpassword, PASSWORD_DEFAULT);
 
 

  $result = mysqli_query($con,"SELECT * FROM `student` WHERE email = '$email'") or exit(mysqli_error()); //check for duplicates
  $num_rows = mysqli_num_rows($result); 
  
   if(($num_rows) > 0){
       echo "<script>alert('Email ID Already Exists')</script>"; 
       exit;
      }
  
//if($fname !="" && $lname !="" && $password !="" && $conf !="" && $gender !="" && $email !="" && $phone !="" && $caste !="" && lang1 !="" && $address !=""){
else{
if(filter_var($email, FILTER_VALIDATE_EMAIL)){
  if($password == $cpassword){
$query ="INSERT INTO `student`(name,email,password,cpassword,phone,address) VALUES ('$name','$email','$password1','$password2','$phone','$address')";
$data=mysqli_query($con,$query);
if($data){
  $login = true;
  session_start();
              $_SESSION['loggedin'] = true;
              $_SESSION['username'] = $email;
  header("location:https://www.psd2htmlx.com/w/bootstrap/bootstrap/profile.php");
}
else{
  echo "<script>alert('You have not been registered')</script>";
}
}else{
$passErr ="Enter similar correct passwords";

}
}
else{
$emailErr ="Please enter a valid mail address";
}
}
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://kit.fontawesome.com/1b5688f48a.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
<style>

  #wrong_pass{
    color:red;
  }
  #wrong{
    color:red;
  }
.see{
  border-radius: 35px;
    padding: 0 25px;
    height: 50px;
    margin: 0;
    display: block;
    float: none;
    width: 100%;
    background: #0E0E0F;
    font-weight: 500;
    color: #FFF;
    border: solid 1px #0E0E0F;
    outline: 0;
    font-family: Klarna Text,Helvetica Neue,Arial,Helvetica,sans-serif;
    font-size: 16px;
    cursor: pointer;
margin:20px 10px 10px 1px;
}
</style>
</head>
  <body>
  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 text-secondary">Home</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Features</a></li>
          <li><a href="#" class="nav-link px-2 text-white">Pricing</a></li>
          <li><a href="#" class="nav-link px-2 text-white">FAQs</a></li>
          <li><a href="#" class="nav-link px-2 text-white">About</a></li>
        </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>

        <div class="text-end">
        <a href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/sign-in.php" class="btn btn-outline-light me-2"> Login</a>
       <a class="btn btn-warning" href="https://www.psd2htmlx.com/w/bootstrap/bootstrap/sign-up.php"> Sign-up</a>
        </div>
      </div>
    </div>
  </header>
    <div class="row">
    <div class="col-md-4 "></div>
        <div class="col-md-4 ">
        <div class="" >
        <h1 class="plan container d-flex align-items-center justify-content-center " center>Register
</h1>
                <form role="form" id="submit-form" action="" method="post">
                <span id="wrong"> <?php echo $emailErr;?></span>
                <span id="wrong_pass"><?php echo $passErr;?></span>
    <div class="form-floating mb-3 ">
      <input type="text" class="form-control" id="floatingInput" placeholder="name" name="name" required>
      <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating mb-3">
      <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email" required>
      <label for="floatingInput">Email address</label>
    </div>
    <div class="form-floating mb-3">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" minlength=8 maxlength=12 required>
      <label for="floatingPassword">Password</label>
    </div>
    <div class="form-floating mb-3">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Confirm-Password" name="cpassword" minlength=8 maxlength=12 required>
      <label for="floatingPassword">Confirm-Password</label>
    </div>
    <div class="form-floating mb-3">
      <input type="tel" class="form-control" id="floatingInput" placeholder="Phone_no." name="phone" maxlength=10 pattern="[0-9]{3}[0-9]{3}[0-9]{4}" onkeypress="return onlyNumberKey(event)" >
      <label for="floatingInput">Phone number</label>
    </div>
    <div class="form-floating mb-3">
      <input type="text" class="form-control" id="floatingInput" placeholder="Address" name="address" minlength=10 maxlength=50 required>
      <label for="floatingInput">Address</label>
    </div>
    <div class="mt-4 d-flex align-items-center justify-content-center mb-3">
    <input class="btn btn-success see" type="submit" value="Sign up" name="submit">
</div >
<div class="card-footer text-center pt-0 px-lg-2 px-1">
                  <p class="mb-2 text-sm mx-auto">
                    Already have an account?
                    <a href="../bootstrap/sign-in.php" class="text-primary text-gradient font-weight-bold">Sign in</a>
                  </p>
                </div>
</form>
</div>
</div>

    <div class="col-md-4 "></div>
<!-- Remove the container if you want to extend the Footer to full width. -->

<footer class="text-white text-center text-lg-start" style="background-color: #23242a;">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">About company</h5>

          <p>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
            voluptatum deleniti atque corrupti.
          </p>

          <p>
            Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas
            molestias.
          </p>

          <div class="mt-4">
            <!-- Facebook -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-facebook-f"></i></a>
            <!-- Dribbble -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-dribbble"></i></a>
            <!-- Twitter -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-twitter"></i></a>
            <!-- Google + -->
            <a type="button" class="btn btn-floating btn-warning btn-lg"><i class="fab fa-google-plus-g"></i></a>
            <!-- Linkedin -->
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4 pb-1">Search something</h5>

          <div class="form-outline form-white mb-4">
            <input type="text" id="formControlLg" class="form-control form-control-lg">
            <label class="form-label" for="formControlLg" style="margin-left: 0px;">Search</label>
          <div class="form-notch"><div class="form-notch-leading" style="width: 9px;"></div><div class="form-notch-middle" style="width: 48.8px;"></div><div class="form-notch-trailing"></div></div></div>

          <ul class="fa-ul" style="margin-left: 1.65em;">
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">New York, NY 10012, US</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">info@example.com</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">+ 01 234 567 88</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-print"></i></span><span class="ms-2">+ 01 234 567 89</span>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Opening hours</h5>

          <table class="table text-center text-white">
            <tbody class="font-weight-normal">
              <tr>
                <td>Mon - Thu:</td>
                <td>8am - 9pm</td>
              </tr>
              <tr>
                <td>Fri - Sat:</td>
                <td>8am - 1am</td>
              </tr>
              <tr>
                <td>Sunday:</td>
                <td>9am - 10pm</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2023 Copyright:oCode Technologies
    </div>
    <!-- Copyright -->
  </footer>

  </body>
</html>
<script>
function onlyNumberKey(evt) {
             
             // Only ASCII character in that range allowed
             var ASCIICode = (evt.which) ? evt.which : evt.keyCode
             if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                 return false;
             return true;
         }
  </script>