<?php
session_start();

session_unset();

$message = "You have been logged out.";
$_SESSION['logout_message'] = $message; // Store the message in a session variable

header('Location: https://localhost/bootstrap/sign-in.php');
exit();
?>
