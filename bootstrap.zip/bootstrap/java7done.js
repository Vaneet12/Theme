window.onload = function(){
    let godesti = localStorage.getItem('destination')
    console.log(godesti,"-------------doing")

    document.getElementById('desti').innerText = godesti;

    let showdata = localStorage.getItem('day')
    let showmonth = localStorage.getItem('MonthName')
    let fulldate =showdata + " " + showmonth;
    console.log(fulldate,"-------------doing")

    document.getElementById('test').innerText = fulldate;

    let gomode = localStorage.getItem('modeOfTravel')
    console.log(gomode,"-------------doing")

    document.getElementById('travelmode').innerText = gomode;
    
    
    let fulldays = localStorage.getItem('days')
    console.log(fulldays,"-------------doing")

    document.getElementById('duration').innerText = fulldays;
  
    let withyou = localStorage.getItem('with')
    console.log(withyou,"-------------doing")

    document.getElementById('withyou').innerText = withyou;

    let doingdo = localStorage.getItem('todoing')
    console.log(doingdo,"-------------doing")
    document.getElementById('fordo').innerText = doingdo;
  
  }

  function pageRedirect() {
    window.location.href="http://localhost/bootstrap/Tour.php";
  } 