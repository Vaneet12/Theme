<!DOCTYPE html>
<html>
<head>
  <title>Logout Message</title>
  <script>
    // Show toast message when the page loads
    window.onload = function() {
      alert('Logged out successfully!');
    };
  </script>
</head>
<body>
  <h1>Logout Message</h1>
  <!-- You can customize the content of this page as needed -->
</body>
</html>