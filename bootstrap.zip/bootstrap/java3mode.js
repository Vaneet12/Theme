function setMode(event) {
    debugger
    localStorage.setItem('modeOfTravel', event)
    debugger
    window.location.href="http://localhost/bootstrap/duration.php";
}

window.onload = function(){
    let showdata = localStorage.getItem('day')
    let showmonth = localStorage.getItem('MonthName')
    let fulldate =showdata + " " + showmonth;
    document.getElementById('test').innerText = fulldate;

    let godesti = localStorage.getItem('destination')
    document.getElementById('desti').innerText = godesti;
}