<?php
include ("connection5.php");
$id= $_GET['id'];
$query="DELETE FROM student WHERE id='$id'";
$data=mysqli_query($con,$query);
if($data)
{
    $response = array('success' => true);



}
else{
    $response = array('success' => false);
}
header('Content-Type: application/json');
echo json_encode($response);

$con->close();
?>