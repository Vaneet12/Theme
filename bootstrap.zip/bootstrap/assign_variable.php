<?php
include("connection6.php");

$el1Value = $_POST['el1']; // Retrieve the value sent from JavaScript
$el2Value = $_POST['el2'];
$el3Value = $_POST['el3'];
$el4Value = $_POST['el4'];
$el5Value = $_POST['el5'];
$el6Value = $_POST['el6'];

// Now you can use $el1Value, $el2Value, $el3Value, $el4Value, $el5Value, $el6Value as needed
$query = "INSERT INTO `multi` (desti, test, travelmode, duration, withyou, fordo)
VALUES ('$el1', '$el2', '$el3', '$el4','$el5','$el6')";

$result = mysqli_query($con, $query);

// Check if the query executed successfully
if ($result) {
    // Data stored successfully
    echo "Data stored in MySQL database.";
} else {
    // An error occurred
    echo "Error: " . mysqli_error($con);
}

// Close the database connection
mysqli_close($con);
?>
