  // Wait for the document to be ready
  $(document).ready(function() {
    // Add a click event handler to the delete buttons
    $(".delete-item").click(function(e) {
      e.preventDefault(); // Prevent the default behavior of the link
      
      // Get the item ID from the data attribute
      var itemId = $(this).data("item-id");
      
      // Make the AJAX request to delete the item
      $.ajax({
        url: 'delete.php?id=' + itemId,
        type: "GET", // or "POST" if applicable
        success: function(response) {
          // Handle the success response (e.g., show a success message)
        alert("Item deleted successfully!");
        },
        error: function(xhr, status, error) {
          // Handle the error response (e.g., display an error message)
          console.log("An error occurred while deleting the item.");
        }
      });
    });
  });
