function pageRedirect(event) {
    localStorage.setItem('destination', event)
    window.location.href = "http://localhost/bootstrap/destination.php";
}