window.onload = function() {
    let godesti = localStorage.getItem('destination')
    document.getElementById('desti').innerText = godesti;
    
}

function pageRedirect(event) {
    localStorage.setItem('day', event['target'].innerHTML);
    window.location.href="https://localhost/bootstrap/Date.php";
  } 
