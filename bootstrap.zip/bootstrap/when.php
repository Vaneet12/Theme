<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
        <script src="https://kit.fontawesome.com/1b5688f48a.js" crossorigin="anonymous"></script>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
<link rel="stylesheet" href="multistyle.css">
<script src="https://localhost/java2.js"></script>

    
</head>
<body>
<div class="swit_submain5">
        <div class="text_div">
            <b>PLANNING YOUR TRIP TO</b>
        </div>
        <div class="switzerland">
            <div>
                <span id="desti"></span>
            </div>

            <a target="_self" href="/">
                <i class="fa fa-times" aria-hidden="true"></i>
            </a>
        </div>
        <div class="progress_div">
            <span class="yellow"></span>
            <span class="grey"></span>
            <span class="grey"></span>
            <span class="grey"></span>
            <span class="grey"></span>
            <span class="grey"></span>
        </div>
        <section class="when_to">
            <h1>When do you wish to travel?</h1>
        </section>
        <div style="text-align: center;">
            <div class="softcard">
                <div class="calendar-bar">
                    <button class="prev soft-btn"><i class="fas fa-chevron-left"></i></button>
                    <div class="current-month"></div>
                    <button class="next soft-btn"><i class="fas fa-chevron-right"></i></button>
                </div>
                <div class="calendar">
                    <div class="weekdays-name">

                        <div class="days-name">Su</div>
                        <div class="days-name">Mo</div>
                        <div class="days-name">Tu</div>
                        <div class="days-name">We</div>
                        <div class="days-name">Th</div>
                        <div class="days-name">Fr</div>
                        <div class="days-name">Sa</div>
                    </div>
                    <div class="calendar-days" onclick="pageRedirect(event)">

                    </div>
                </div>
            </div>
        </div>




    </div>


</body>
</html>