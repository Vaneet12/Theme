<?php
  $phpVariable = $_POST['godesti'];
  echo $phpVariable; 
?>